## Incsub

[Live](https://incsub-test.vercel.app/)

- navigate to the folder

```sh
npm install
npm run dev
```

import './src/sass/main.scss';
import passwordShow from './src/js/password-show';
import formValidation from './src/js/form-validation';

formValidation();
passwordShow();
